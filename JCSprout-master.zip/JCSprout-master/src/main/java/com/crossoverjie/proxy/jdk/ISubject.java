package com.crossoverjie.proxy.jdk;

/**
 * Function:
 *
 * @author crossoverJie
 *         Date: 23/12/2017 22:37
 * @since JDK 1.8
 */
public interface ISubject {

    /**
     * 执行
     */
    void execute() ;
}
