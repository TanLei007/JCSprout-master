# SHOW TIME

> 请科学上网

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/MAshLFlBRLU" frameborder="0" allowfullscreen></iframe>


---
<iframe width="560" height="315" src="https://www.youtube.com/embed/HhDEQSb2nAY" frameborder="0" allowfullscreen></iframe>

---

<iframe width="560" height="315" src="https://www.youtube.com/embed/Zk6Psbxhvtc" frameborder="0" allowfullscreen></iframe>

---




----------
# CONTACT
> - [微博](http://weibo.com/crossoverJie "微博")
> - [GitHub](https://github.com/crossoverJie "github")
> - [crossoverJie@gmail.com](mailto:crossoverjie@gmail.com)

[![QQ群](https://img.shields.io/badge/QQ%E7%BE%A4-787381170-yellowgreen.svg)](https://jq.qq.com/?_wv=1027&k=5HPYvQk)

**欢迎我的关注公众号一起交流：**

![](https://ws3.sinaimg.cn/large/006tKfTcgy1fsuvb4ebtmj30760760t7.jpg)

