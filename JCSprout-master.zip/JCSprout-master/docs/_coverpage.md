

<img src="_media/icon-left-font-monochrome-black.png"  width="400" />


> `Java Core Sprout`：处于萌芽阶段的 Java 核心知识库。

[GitHub](https://github.com/crossoverJie/JCSprout)
[Get Started](#introduction)